// Get the paragraph from the fieldset 'Costs' using the document.querySelector()
// All info about the prices of the products being selected at current time will be displayed in this paragraph
let paragraph = document.querySelector('#costs');

// The total cost of all the options selected (tax included/computed) will be displayed in this paragraph
let cost_paragraph = document.querySelector('#totalCost');

// Note => "&nbsp;&nbsp;&nbsp;&nbsp;" adds a tab
// Assign a variable to hold the prices for each availabe size of pizza
let size_text = `Pizza size: <br/>
&nbsp;&nbsp;&nbsp;&nbsp; Small - 125 pesos <br/>
&nbsp;&nbsp;&nbsp;&nbsp; Medium - 250 pesos <br/>
&nbsp;&nbsp;&nbsp;&nbsp; Large - 500 pesos <br/><br/>`;

// Assign a variable to hold the prices for each crust type variation
let crustType_text = `Crust type <br/>
&nbsp;&nbsp;&nbsp;&nbsp; Thin - 50 pesos <br/>
&nbsp;&nbsp;&nbsp;&nbsp; Thick - 70 pesos <br/><br/>`;

// Assign a variable to hold the prices for each size main topping
let mainToppings_text = `Main toppings <br/>
&nbsp;&nbsp;&nbsp;&nbsp; Pepperoni overload - 100 pesos <br/>
&nbsp;&nbsp;&nbsp;&nbsp; Hawaiian - 50 pesos <br/>
&nbsp;&nbsp;&nbsp;&nbsp; Meat overload - 125 pesos <br/> <br/>`;

/*------------------------------------------------------------------------------------------
Assign variables for the partial data that will be stored in the additionalToppings_text below*/
let moreVegetables = `&nbsp;&nbsp;&nbsp;&nbsp; More vegetables - 12 pesos <br/>`;

let moreMeat = `&nbsp;&nbsp;&nbsp;&nbsp; More meat - 75 pesos <br/>`;

let moreCheese = `&nbsp;&nbsp;&nbsp;&nbsp; More cheese - 50 pesos <br/><br/>`;
//--------------------------------------------------------------------------------------------
// Assign a variable to hold the prices for each additional topping
let additionalToppings_text = `Additional toppings  <br/>` + moreVegetables + moreMeat + moreCheese;

//--------------------------------------------------------------------------------------------
// Assign temporary variables for the costs of the options selected
let size_cost = 0;
let crustType_cost = 0;
let mainToppings_cost = 0;
// cost of each additional topping selected
let moreVegetables_cost = 0;
let moreMeat_cost = 0;
let moreCheese_cost = 0;

// for the total cost
let total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;
//--------------------------------------------------------------------------------------------

// Assign a variable to hold the total costs of all options selected by the customer in current time
let total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

// Assign a variable to hold the total cost of the pizza (tax included/computed
let pizza_cost = total_cost + total_cost*0.12;

// Assign a variable for the text that will replace the fetched paragraph
let text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;

// replace the contents of the paragraph with the variable text's contents
paragraph.innerHTML = text;

// replace the contents fo the second paragraph with the pizza_cost contents
cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

/*Before manipulating the data in our array text, make sure that will store its initial value to 
another variable so that when we decide to reset the form, the contents of the 2 paragraphs in the form will also 
be reverted back to their original contents (paragraph and cost_paragraph)  */
const resetText = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
const resetPizza_cost = total_cost + total_cost*0.12;


//------------------------------------------------------------------------------------------------------------------------
/*The block of codes below make changes in the contents of the paragraph we've fetched earlier*/
// To say, when some options are selected, we'll display in our fetched paragraphed that these options are currently selected

//************************************************************************************************************************

// If the radio small size option is selected, we'll display in our paragraph that it is selected
const size_small = document.querySelector('#size_small');
const size_small_text = document.querySelector('#size_small_text');



[size_small, size_small_text].forEach(function(element) {element.addEventListener('mousedown', (event) => {
	

	// Changes the content of the variable size_text
	size_text = `Pizza size: <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Small (selected) - 125 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Medium - 250 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Large - 500 pesos <br/><br/>`;

	// Changes the value of the variable size_cost
	size_cost = 125;

	//updates the value of the variable total_cost
	total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

	//updates the contents of the total_text variable
	total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

	// updates the contents of the variable pizza_cost
	pizza_cost = total_cost + total_cost*0.12;

	// updates the contents of the cost_paragraph
	cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

	// updates the contents of the text variable
	text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
	
	// updates the contents of the paragraph
	paragraph.innerHTML = text;


	
})})

// If the radio medium size option is selected, we'll display in our paragraph that it is selected
const size_medium = document.querySelector('#size_medium');
const size_medium_text = document.querySelector('#size_medium_text');

[size_medium, size_medium_text].forEach(function(element) {element.addEventListener('mousedown', (event) => {
	// Changes the content of the variable size_text
	size_text = `Pizza size: <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Small - 125 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Medium (selected) - 250 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Large - 500 pesos <br/><br/>`;

	// Changes the value of the variable size_cost
	size_cost = 250;

	//updates the value of the variable total_cost
	total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

	//updates the contents of the total_text variable
	total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

	// updates the contents of the variable pizza_cost
	pizza_cost = total_cost + total_cost*0.12;

	// updates the contents of the cost_paragraph
	cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

	// updates the contents of the text variable
	text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
	
	// updates the contents of the paragraph
	paragraph.innerHTML = text;
})})


// If the radio large size option is selected, we'll display in our paragraph that it is selected
const size_large = document.querySelector('#size_large');
const size_large_text = document.querySelector('#size_large_text');

[size_large, size_large_text].forEach(function(element) {element.addEventListener('mousedown', (event) => {
	// Changes the content of the variable size_text
	size_text = `Pizza size: <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Small - 125 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Medium - 250 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Large (selected) - 500 pesos <br/><br/>`;

	// Changes the value of the variable size_cost
	size_cost = 500;

	//updates the value of the variable total_cost
	total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

	//updates the contents of the total_text variable
	total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

	// updates the contents of the variable pizza_cost
	pizza_cost = total_cost + total_cost*0.12;

	// updates the contents of the cost_paragraph
	cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

	// updates the contents of the text variable
	text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
	
	// updates the contents of the paragraph
	paragraph.innerHTML = text;
})})


//************************************************************************************************************************

// If the thin crust type option is selected, we'll display in our paragraph that it is selected
const crustType_thin = document.querySelector('#crustType_thin');
const crustType_thin_text = document.querySelector('#crustType_thin_text');

[crustType_thin, crustType_thin_text].forEach(function(element) {element.addEventListener('mousedown', (event) => {
	// Changes the content of the variable crustType_text
	crustType_text = `Crust type <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Thin (selected) - 50 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Thick - 70 pesos <br/><br/>`;

	// Changes the value of the variable crustType_cost
	crustType_cost = 50;

	//updates the value of the variable total_cost
	total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

	//updates the contents of the total_text variable
	total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

	// updates the contents of the variable pizza_cost
	pizza_cost = total_cost + total_cost*0.12;

	// updates the contents of the cost_paragraph
	cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

	// updates the contents of the text variable
	text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
	
	// updates the contents of the paragraph
	paragraph.innerHTML = text;
})})

// If the thick crust type option is selected, we'll display in our paragraph that it is selected
const crustType_thick = document.querySelector('#crustType_thick');
const crustType_thick_text = document.querySelector('#crustType_thick_text');

[crustType_thick, crustType_thick_text].forEach(function(element) {element.addEventListener('mousedown', (event) => {
	// Changes the content of the variable crustType_text
	crustType_text = `Crust type <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Thin - 50 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Thick (selected) - 70 pesos <br/><br/>`;

	// Changes the value of the variable crustType_cost
	crustType_cost = 70;

	//updates the value of the variable total_cost
	total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

	//updates the contents of the total_text variable
	total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

	// updates the contents of the variable pizza_cost
	pizza_cost = total_cost + total_cost*0.12;

	// updates the contents of the cost_paragraph
	cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

	// updates the contents of the text variable
	text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
	
	// updates the contents of the paragraph
	paragraph.innerHTML = text;
})})

//************************************************************************************************************************

// Get the dropdown list from our html file and store it in a variable
const mainToppings = document.querySelector('#mainToppings');

// if one of the main toppings' options is selected, display in our paragraph that it is selected
mainToppings.onchange = function() {
	var mainToppings_select = document.querySelector("#mainToppings").value;

	// if the Pepperoni overload is selected
	if (mainToppings_select == 'Pepperoni overload') {
		// Changes the content of the variable mainToppings_text
		mainToppings_text = `Main toppings <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Pepperoni overload (selected) - 100 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Hawaiian - 50 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Meat overload - 125 pesos <br/> <br/>`;

		// Changes the value of the variable mainToppings_cost
		mainToppings_cost = 100;

		//updates the value of the variable total_cost
		total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

		//updates the contents of the total_text variable
		total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

		// updates the contents of the variable pizza_cost
		pizza_cost = total_cost + total_cost*0.12;

		// updates the contents of the cost_paragraph
		cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

		// updates the contents of the text variable
		text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
		
		// updates the contents of the paragraph
		paragraph.innerHTML = text;

	// if the Hawaiian is selected
	} else if (mainToppings_select == 'Hawaiian') {
		// Changes the content of the variable mainToppings_text
		mainToppings_text = `Main toppings <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Pepperoni overload - 100 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Hawaiian (selected) - 50 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Meat overload - 125 pesos <br/> <br/>`;

		// Changes the value of the variable mainToppings_cost
		mainToppings_cost = 50;

		//updates the value of the variable total_cost
		total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

		//updates the contents of the total_text variable
		total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

		// updates the contents of the variable pizza_cost
		pizza_cost = total_cost + total_cost*0.12;

		// updates the contents of the cost_paragraph
		cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

		// updates the contents of the text variable
		text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
		
		// updates the contents of the paragraph
		paragraph.innerHTML = text;

	// if the Meat overload is selected
	} else if (mainToppings_select == 'Meat overload') {
		// Changes the content of the variable mainToppings_text
		mainToppings_text = `Main toppings <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Pepperoni overload - 100 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Hawaiian - 50 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Meat overload (selected) - 125 pesos <br/> <br/>`;

		// Changes the value of the variable mainToppings_cost
		mainToppings_cost = 125;

		//updates the value of the variable total_cost
		total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

		//updates the contents of the total_text variable
		total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

		// updates the contents of the variable pizza_cost
		pizza_cost = total_cost + total_cost*0.12;

		// updates the contents of the cost_paragraph
		cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

		// updates the contents of the text variable
		text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
		
		// updates the contents of the paragraph
		paragraph.innerHTML = text;

	// if none of the three options is selected
	} else {
		// Changes the content of the variable mainToppings_text
		mainToppings_text = `Main toppings <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Pepperoni overload - 100 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Hawaiian - 50 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Meat overload - 125 pesos <br/> <br/>`;

		// Changes the value of the variable mainToppings_cost
		mainToppings_cost = 0;

		//updates the value of the variable total_cost
		total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

		//updates the contents of the total_text variable
		total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

		// updates the contents of the variable pizza_cost
		pizza_cost = total_cost + total_cost*0.12;

		// updates the contents of the cost_paragraph
		cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

		// updates the contents of the text variable
		text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
		
		// updates the contents of the paragraph
		paragraph.innerHTML = text;
	}

}

//************************************************************************************************************************

// If the checkbox - more vegetables is selected, we'll display in our paragraph that it is selected
const toppings_moreVegetables = document.querySelector('#toppings_moreVegetables');
const toppings_moreVegetables_text = document.querySelector('#toppings_moreVegetables_text');

// assign a variable that will increment its value whenever we click the checkbox more vegetables
var moreVegetables_validator = 0;

[toppings_moreVegetables, toppings_moreVegetables_text].forEach(function(element) {element.addEventListener('mousedown', (event) => {
	// increment the validator's value whenever we click the checkbox
	moreVegetables_validator ++

	// if the validator's value is divided by 2 and the remainder is not 0, make changes to our paragraph 
	if (moreVegetables_validator%2 != 0) {
		// Changes the content of the variable moreVegetables
		moreVegetables = `&nbsp;&nbsp;&nbsp;&nbsp; More vegetables (selected) - 12 pesos <br/>`;

		// Changes the value of the variable moreVegetables_cost
		moreVegetables_cost = 12;
	} else {
		moreVegetables = `&nbsp;&nbsp;&nbsp;&nbsp; More vegetables - 12 pesos <br/>`

		// Changes the value of the variable moreVegetables_cost
		moreVegetables_cost = 0;
	}

	// updates the contents of the additionalToppings_text variable
	additionalToppings_text = `Additional toppings  <br/>` + moreVegetables + moreMeat + moreCheese;

	//updates the value of the variable total_cost
	total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

	//updates the contents of the total_text variable
	total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

	// updates the contents of the variable pizza_cost
	pizza_cost = total_cost + total_cost*0.12;

	// updates the contents of the cost_paragraph
	cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

	// updates the contents of the text variable
	text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
	
	// updates the contents of the paragraph
	paragraph.innerHTML = text;
})})


// If the checkbox - more meat is selected, we'll display in our paragraph that it is selected
const toppings_moreMeat = document.querySelector('#toppings_moreMeat');
const toppings_moreMeat_text = document.querySelector('#toppings_moreMeat_text');

// assign a variable that will increment its value whenever we click the checkbox more meat
var moreMeat_validator = 0;

[toppings_moreMeat, toppings_moreMeat_text].forEach(function(element) {element.addEventListener('mousedown', (event) => {
	// increment the validator's value whenever we click the checkbox
	moreMeat_validator ++

	// if the validator's value is divided by 2 and the remainder is not 0, make changes to our paragraph 
	if (moreMeat_validator%2 != 0) {
		// Changes the content of the variable moreMeat
		moreMeat = `&nbsp;&nbsp;&nbsp;&nbsp; More meat (selected) - 75 pesos <br/>`;

		// Changes the value of the variable moreMeat_cost
		moreMeat_cost = 75;		
	} else {
		moreMeat = `&nbsp;&nbsp;&nbsp;&nbsp; More meat - 75 pesos <br/>`;

		// Changes the value of the variable moreMeat_cost
		moreMeat_cost = 0;
	}

	// updates the contents of the additionalToppings_text variable
	additionalToppings_text = `Additional toppings  <br/>` + moreVegetables + moreMeat + moreCheese;

	//updates the value of the variable total_cost
	total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

	//updates the contents of the total_text variable
	total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

	// updates the contents of the variable pizza_cost
	pizza_cost = total_cost + total_cost*0.12;

	// updates the contents of the cost_paragraph
	cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

	// updates the contents of the text variable
	text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
	
	// updates the contents of the paragraph
	paragraph.innerHTML = text;
})})


// If the checkbox - more cheese is selected, we'll display in our paragraph that it is selected
const toppings_moreCheese = document.querySelector('#toppings_moreCheese');
const toppings_moreCheese_text = document.querySelector('#toppings_moreCheese_text');

// assign a variable that will increment its value whenever we click the checkbox more cheese
var moreCheese_validator = 0;

[toppings_moreCheese, toppings_moreCheese_text].forEach(function(element) {element.addEventListener('mousedown', (event) => {
	// increment the validator's value whenever we click the checkbox
	moreCheese_validator ++

	// if the validator's value is divided by 2 and the remainder is not 0, make changes to our paragraph 
	if (moreCheese_validator%2 != 0) {
		// Changes the content of the variable moreCheese
		moreCheese = `&nbsp;&nbsp;&nbsp;&nbsp; More cheese (selected) - 50 pesos <br/><br/>`;

		// Changes the value of the variable moreCheese_cost
		moreCheese_cost = 50;
	} else {
		moreCheese = `&nbsp;&nbsp;&nbsp;&nbsp; More cheese - 50 pesos <br/><br/>`;

		// Changes the value of the variable moreCheese_cost
		moreCheese_cost = 0;
	}

	// updates the contents of the additionalToppings_text variable
	additionalToppings_text = `Additional toppings  <br/>` + moreVegetables + moreMeat + moreCheese;

	//updates the value of the variable total_cost
	total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;

	//updates the contents of the total_text variable
	total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;

	// updates the contents of the variable pizza_cost
	pizza_cost = total_cost + total_cost*0.12;

	// updates the contents of the cost_paragraph
	cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

	// updates the contents of the text variable
	text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
	
	// updates the contents of the paragraph
	paragraph.innerHTML = text;
})})

//************************************************************************************************************************

const reset_button = document.querySelector('#reset_button')
// data in the costs fieldset will be reset
reset_button.addEventListener('mousedown', (event) => {

	// resets the values of the validators for the checkboxes
	moreVegetables_validator = 0;
	moreMeat_validator = 0;
	moreCheese_validator = 0;


	// The blocks of code below just resets the original values of all variables
	//  These are just exact copies of the original variables

	size_text = `Pizza size: <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Small - 125 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Medium - 250 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Large - 500 pesos <br/><br/>`;

	crustType_text = `Crust type <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Thin - 50 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Thick - 70 pesos <br/><br/>`;

	mainToppings_text = `Main toppings <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Pepperoni overload - 100 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Hawaiian - 50 pesos <br/>
	&nbsp;&nbsp;&nbsp;&nbsp; Meat overload - 125 pesos <br/> <br/>`;

	moreVegetables = `&nbsp;&nbsp;&nbsp;&nbsp; More vegetables - 12 pesos <br/>`;
	moreMeat = `&nbsp;&nbsp;&nbsp;&nbsp; More meat - 75 pesos <br/>`;
	moreCheese = `&nbsp;&nbsp;&nbsp;&nbsp; More cheese - 50 pesos <br/><br/>`;
	additionalToppings_text = `Additional toppings  <br/>` + moreVegetables + moreMeat + moreCheese;

	size_cost = 0;
	crustType_cost = 0;
	mainToppings_cost = 0;

	moreVegetables_cost = 0;
	moreMeat_cost = 0;
	moreCheese_cost = 0;

	total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;
	total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;
	pizza_cost = total_cost + total_cost*0.12;
	text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
	paragraph.innerHTML = text;
	cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;

})

//************************************************************************************************************************

// get the element time input from our html file by specifying its id
const inputTime = document.querySelector('#time')

// create a date class of the current date and time
// this is necessary for us later for:
// 1. we can use this to change the minimum value the input time can accept (so that we can make sure that the order we'll be processed only within the 24-hour period)
const date_now = new Date();

// create an empty array to hold the number of hours and minutes of the current date
let dateHours = [];

// fetch the number of hours and minutes of the current date and put it inside our empty array
dateHours.push(date_now.getHours())
dateHours.push(date_now.getMinutes())

// Compare the hours inside our array dateHours with the original minimum hour attribute inside our input time
// if the number of hours in our current date is less than the original minimum hour, we'll set the attribute minimum to 10 A.M.
// if the number of hours in our current date is greater than the original minimum hour, we'll set the attribute minimum to the current time.
if (dateHours[0] < 10 ) {
	inputTime.setAttribute('min', '10:00:00')
} else if (dateHours[0] >= 10) {
	inputTime.setAttribute('min', `${dateHours[0]}:${dateHours[1]}:00`)
}

// fetch other attributes of the current date
let year = date_now.getFullYear();
let month = date_now.getMonth();
let day = date_now.getDate();

//************************************************************************************************************************

// Get the element form using the querySelector
const form = document.querySelector('#form');

// Get the submit button from our html file
const submit_button = document.querySelector('#submit_button')

// Submit the details of the form to a certain server when the submit button is clicked/approved
form.addEventListener('submit', function(event) {
	// This prevents the web from redirecting/going to the server's url
	event.preventDefault();

	// Data inside the form will be individually stored in variables
	const {customer_name, email_address, customer_address, mobile_number, expected_delivery_time, size, crust_type, main_toppings, additional_toppings, additional_requests} = form;

	//------------------------------------------------------
	// the block of code below fixes the issue of not being able to display the data of the additional toppings
	const additional_toppings_array = [];
	for (const node of additional_toppings) {
		if (node.checked) {
			additional_toppings_array.push(node.value)
		}
	}

	// store the recorded expected delivery time to a variable
	const delivery_time = expected_delivery_time.value;

	// Make an array containing the number of hours and minutes of the expected delivery time
	let deliveryHours = delivery_time.split(":")

	// Create a date class to record the date of the expected delivery time so that we can convert it to UNIX - epoch format later
	const deliveryDate = new Date(`${year}`, `${month}`, `${day}`, `${deliveryHours[0]}`, `${deliveryHours[1]}`);

	// Assign a variable to contain data from the form
	const data = {
		'Name': customer_name.value,
		'Email': email_address.value,
		'Address': customer_address.value,
		'Phone number': mobile_number.value,
		'Time of expected delivery UNIX EPOCH': deliveryDate.getTime(), // convert date to UNIX - epoch format
		'Pizza size': size.value,
		'Crust type': crust_type.value,
		'Main toppings': main_toppings.value,
		'Additional toppings': additional_toppings_array, // this is an array
		'Additional requests': additional_requests.value,
		'Total cost': pizza_cost // this is a float
	}

	// Disable the submit button while waiting for the processing of data
	submit_button.setAttribute('disabled','disabled');


	setTimeout(async function () {
		// Data gathered will be displayed in the cursor
		console.log(data);

		// Enables the submit button again
		submit_button.removeAttribute('disabled');

		// Data gathered will then be submitted to the server
		const response = await fetch(form.action, {
			method: form.method,
			body: JSON.stringify(data)
		})

		const response_text = await response.text();		

		// Display the data gathered
		alert(`Thank You for Ordering! \r\n\r\n Your order has been successfully processed to the server url http://httpbin.org/anything \r\n\r\n Please prepare the payment before the time of delivery \r\n\r\n Note: Complete details of order can be seen in the browser's console. \r\n[Inspect Element (Ctrl + Shift + I) => Console] \r\n\r\n ${response_text}`)

		// Resets each input fields
		form.reset()

		// Resets the values of inputs in the form
		// resets the values of the validators for the checkboxes
		moreVegetables_validator = 0;
		moreMeat_validator = 0;
		moreCheese_validator = 0;

		// The blocks of code below just resets the original values of all variables
		//  These are just exact copies of the original variables

		size_text = `Pizza size: <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Small - 125 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Medium - 250 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Large - 500 pesos <br/><br/>`;

		crustType_text = `Crust type <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Thin - 50 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Thick - 70 pesos <br/><br/>`;

		mainToppings_text = `Main toppings <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Pepperoni overload - 100 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Hawaiian - 50 pesos <br/>
		&nbsp;&nbsp;&nbsp;&nbsp; Meat overload - 125 pesos <br/> <br/>`;

		moreVegetables = `&nbsp;&nbsp;&nbsp;&nbsp; More vegetables - 12 pesos <br/>`;
		moreMeat = `&nbsp;&nbsp;&nbsp;&nbsp; More meat - 75 pesos <br/>`;
		moreCheese = `&nbsp;&nbsp;&nbsp;&nbsp; More cheese - 50 pesos <br/><br/>`;
		additionalToppings_text = `Additional toppings  <br/>` + moreVegetables + moreMeat + moreCheese;

		size_cost = 0;
		crustType_cost = 0;
		mainToppings_cost = 0;

		moreVegetables_cost = 0;
		moreMeat_cost = 0;
		moreCheese_cost = 0;

		total_cost = size_cost + crustType_cost + mainToppings_cost + moreVegetables_cost + moreMeat_cost + moreCheese_cost;
		total_text = `Total: <br/> ${size_cost} + ${crustType_cost} + ${mainToppings_cost} + ${moreVegetables_cost} + ${moreMeat_cost} + ${moreCheese_cost} = ${total_cost} pesos + 12% tax`;
		pizza_cost = total_cost + total_cost*0.12;
		text = size_text + crustType_text + mainToppings_text + additionalToppings_text + total_text;
		paragraph.innerHTML = text;
		cost_paragraph.innerHTML = `To pay: ${pizza_cost} pesos`;


	}, 2000); // wait for two seconds to process the submit function

})

